<?php

include "page_action/batch_page_action.php";

?>