
    <?php
        define('db_host', 'localhost');
        define('db_user', 'root');
        define('db_pass', '');
        define('db_name', 'bits');
    ?>
    