<?php

include "layout/header.php";
include "page/id_card/id_card_editor/id_card_editor.php";
include "layout/footer.php";

 ?>



 