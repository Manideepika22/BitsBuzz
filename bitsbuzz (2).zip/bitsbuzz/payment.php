<?php

include "layout/header.php";
include "page/payment/payment.php";
include "layout/footer.php";
?>