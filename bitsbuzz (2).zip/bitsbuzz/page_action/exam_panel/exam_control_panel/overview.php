<?php




if(isset($_POST['exam_overview'])){

?>

<div class="row">
	<div class="col-md-4">
		
		<div class="div_he">
			Mark Distribuation
			asdf
		</div>
	</div>
	<div class="col-md-8">
		
		<div class="div_he">
			Mark Distribuation
			asdf

		</div>
		<div class="cls_right">
			<center>
				<button class="btn">Add Mark</button>
			</center>
			<table width="100%">
				<tr>
					<td>#</td>
					<td>Name</td>
					<td>Mark</td>
				</tr>
			</table>
		</div>
	</div>
</div>
<style type="text/css">
	.div_he{
		background-color: #ECECEC;
		text-align: center;
		padding: 5px;
		color: #000000;
		font-weight: bold;

	}
	.cls_right{
		padding: 10px;
		border: 1px solid #ECECEC;
	}
	
</style>

<?php

}


?>